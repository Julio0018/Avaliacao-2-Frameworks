import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '../stores/auth'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/LoginView.vue'),
    meta: { requiresGuest: true }
  },
  {
    path: '/auth/callback',
    name: 'AuthCallback',
    component: () => import('../views/AuthCallbackView.vue')
  },
  {
    path: '/',
    name: 'Dashboard',
    component: () => import('../views/DashboardView.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/projects',
    name: 'Projects',
    component: () => import('../views/ProjectsView.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/projects/new',
    name: 'NewProject',
    component: () => import('../views/ProjectFormView.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/projects/edit/:id',
    name: 'EditProject',
    component: () => import('../views/ProjectFormView.vue'),
    meta: { requiresAuth: true }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach(async (to, from, next) => {
  const authStore = useAuthStore()

  if (!authStore.isInitialized) {
    try {
      await new Promise((resolve) => {
        const checkInitialized = () => {
          if (authStore.isInitialized) {
            resolve()
          } else {
            setTimeout(checkInitialized, 50)
          }
        }
        checkInitialized()
      })
    } catch (error) {
      console.error('Erro ao aguardar inicialização:', error)
    }
  }

  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    next('/login')
  } 
  else if (to.meta.requiresGuest && authStore.isAuthenticated) {
    next('/')
  } 
  else {
    next()
  }
})

export default router