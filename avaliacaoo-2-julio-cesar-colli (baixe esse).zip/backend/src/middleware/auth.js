const authMiddleware = (req, res, next) => {
  console.log('Middleware de autenticação executado');
  next();
};

export default authMiddleware;
