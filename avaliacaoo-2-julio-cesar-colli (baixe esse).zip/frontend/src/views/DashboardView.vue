<template>
  <v-container>
    <v-row>
      <v-col cols="12">
        <v-card>
          <v-card-title class="text-h5">
            <v-icon icon="mdi-view-dashboard" class="mr-2"></v-icon>
            Dashboard
          </v-card-title>
          <v-card-text>
            <p class="text-body-1 mb-4">Bem-vindo ao sistema de gestão de projetos!</p>
            
            <v-row>
              <v-col cols="12" md="3" v-for="stat in stats" :key="stat.title">
                <v-card variant="outlined" class="text-center pa-4">
                  <div class="text-h4 font-weight-bold mb-2">{{ stat.value }}</div>
                  <div class="text-body-2">{{ stat.title }}</div>
                </v-card>
              </v-col>
            </v-row>

            <v-row class="mt-6">
              <v-col cols="12" class="text-center">
                <v-btn color="primary" size="large" @click="$router.push('/projects')">
                  <v-icon icon="mdi-folder" class="mr-2"></v-icon>
                  Gerenciar Projetos
                </v-btn>
              </v-col>
            </v-row>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { api } from '../services/api'

const projects = ref([])

const stats = computed(() => [
  { title: 'Total de Projetos', value: projects.value.length },
  { title: 'Em Andamento', value: projects.value.filter(p => p.status === 'em_andamento').length },
  { title: 'Concluídos', value: projects.value.filter(p => p.status === 'concluido').length },
  { title: 'Pendentes', value: projects.value.filter(p => p.status === 'pendente').length }
])

const loadProjects = async () => {
  try {
    projects.value = await api.get('/projects')
  } catch (error) {
    console.error('Erro ao carregar projetos:', error)
  }
}

onMounted(() => {
  loadProjects()
})
</script>