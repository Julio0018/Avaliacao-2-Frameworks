<template>
  <v-container>
    <v-row>
      <v-col cols="12" md="8" offset-md="2" lg="6" offset-lg="3">
        <v-card>
          <v-card-title class="text-h5 d-flex justify-center pa-4">
            <v-icon :icon="isEdit ? 'mdi-pencil' : 'mdi-plus'" class="mr-2"></v-icon>
            {{ isEdit ? 'Editar Projeto' : 'Novo Projeto' }}
          </v-card-title>
          
          <v-card-text class="pt-4">
            <v-form @submit.prevent="submitForm">
              <v-text-field
                v-model="form.title"
                label="Título do Projeto"
                required
                :error-messages="errors.title"
                variant="outlined"
                class="mb-4"
              ></v-text-field>
              
              <v-textarea
                v-model="form.description"
                label="Descrição"
                rows="3"
                :error-messages="errors.description"
                variant="outlined"
                class="mb-4"
              ></v-textarea>
              
              <v-row>
                <v-col cols="12" md="6">
                  <v-select
                    v-model="form.status"
                    label="Status"
                    :items="statusOptions"
                    :error-messages="errors.status"
                    variant="outlined"
                    class="mb-4"
                  ></v-select>
                </v-col>
                
                <v-col cols="12" md="6">
                  <v-select
                    v-model="form.priority"
                    label="Prioridade"
                    :items="priorityOptions"
                    :error-messages="errors.priority"
                    variant="outlined"
                    class="mb-4"
                  ></v-select>
                </v-col>
              </v-row>
              
              <v-text-field
                v-model="form.deadline"
                label="Prazo de Entrega"
                type="date"
                :error-messages="errors.deadline"
                variant="outlined"
                class="mb-6"
                :min="minDate"
              ></v-text-field>

              <v-card-actions class="px-0 d-flex justify-center">
                <v-btn 
                  type="submit" 
                  color="primary" 
                  :loading="loading"
                  prepend-icon="mdi-content-save"
                  class="mr-2"
                >
                  {{ isEdit ? 'Atualizar' : 'Criar' }} Projeto
                </v-btn>
                
                <v-btn 
                  @click="$router.back()"
                  variant="outlined"
                >
                  Cancelar
                </v-btn>
              </v-card-actions>
            </v-form>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { api } from '../services/api'

const route = useRoute()
const router = useRouter()

const isEdit = computed(() => route.name === 'EditProject')
const loading = ref(false)

const form = ref({
  title: '',
  description: '',
  status: 'pendente',
  priority: 'media',
  deadline: null
})

const errors = ref({})

const statusOptions = [
  { title: 'Pendente', value: 'pendente' },
  { title: 'Em Andamento', value: 'em_andamento' },
  { title: 'Concluído', value: 'concluido' },
  { title: 'Cancelado', value: 'cancelado' }
]

const priorityOptions = [
  { title: 'Baixa', value: 'baixa' },
  { title: 'Média', value: 'media' },
  { title: 'Alta', value: 'alta' },
  { title: 'Urgente', value: 'urgente' }
]

const minDate = computed(() => {
  return new Date().toISOString().split('T')[0]
})

const validateForm = () => {
  errors.value = {}
  
  if (!form.value.title.trim()) {
    errors.value.title = 'Título é obrigatório'
  }
  
  if (!form.value.deadline) {
    errors.value.deadline = 'Prazo é obrigatório'
  }
  
  return Object.keys(errors.value).length === 0
}

const submitForm = async () => {
  if (!validateForm()) return
  
  loading.value = true
  try {
    if (isEdit.value) {
      await api.put(`/projects/${route.params.id}`, form.value)
    } else {
      await api.post('/projects', form.value)
    }
    router.push('/projects')
  } catch (error) {
    console.error('Erro ao salvar projeto:', error)
    alert('Erro ao salvar projeto. Tente novamente.')
  } finally {
    loading.value = false
  }
}

const loadProject = async () => {
  if (!isEdit.value) return
  
  try {
    const project = await api.get(`/projects/${route.params.id}`)
    form.value = { ...project }
  } catch (error) {
    console.error('Erro ao carregar projeto:', error)
    alert('Erro ao carregar projeto')
    router.push('/projects')
  }
}

onMounted(() => {
  loadProject()
})
</script>